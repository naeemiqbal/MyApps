Ext.define('BISM.controller.Parts', {
    extend: 'Ext.app.Controller',
    stores: 'Parts@BISM.store',
    models: 'Part@BISM.model',
    //views: ['List@BISM.view.parts', 'Edit@BISM.view.parts'],
    //refs: [{ref: 'partsPanel', selector: 'panel'}],
    init: function () {
        this.control({' partsedit button[action=save]': {click: this.updatePart}});
        this.control({' partslist': {itemdblclick: this.editPart}});
    },
    
    editPart: function (grid, record) {
        var editw = Ext.create('BISM.view.parts.Edit',{singleton: true});
        editw.show();
        editw.down('form').loadRecord(record);
    },
    
    updatePart: function(button){
        var win = button.up('window'),
                form = win.down('form'),
                record = form.getRecord(),
                values = form.getValues();
        record.set(values);
        win.close();
        
    }
});