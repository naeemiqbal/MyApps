Ext.define('BISM.view.parts.Edit', {
    extend: 'Ext.window.Window',
    alias: 'widget.partsedit',
    title: 'Edit a part',
    requires: 'Ext.form.Panel',
    layout: 'fit',
    autoShow: true,
    width: 400,
//    singleton: true,
    initComponent: function () {
        this.items = [
            {
                xtype: 'form',
                items: [
                    {
                        xtype: 'numberfield',
                        name: 'partid',
                        fieldLabel: 'Part ID'
                    },
                    {
                        xtype: 'textfield',
                        name: 'partdesc',
                        fieldLabel: 'Description'
                    },
                    {
                        xtype: 'datefield',
                        name: 'productiondate',
                        fieldLabel: 'Date of Birth'
                    }
                ]
            }
        ];
        this.buttons = [
            {
                text : 'Save',
                action: 'save'
            },
            {
                text: 'Close',
                scope : this,
                //handler : function() { this.close();}
                handler: this.close
            }
        ];
        this.callParent(arguments);
    }


});